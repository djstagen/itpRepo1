﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace UnNamedTheGame
{
    class StartArea
    {
        string Name;

        public StartArea()
        {
            
        }

        public void Run()
        {
            WriteLine("You wake up to find yourself. \n What was my name again? \n It seems you have forgetten.");

        }
    }
}
